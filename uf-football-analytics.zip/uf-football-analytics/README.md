# Florida Gators Football Analytics

**A reproducible performance analytics report on the UF football program (2022–2024)**  
Built with public data from the [College Football Data API](https://collegefootballdata.com).

---

## Motivation

The UF Sports Analytics Lab sits at the intersection of applied sport science and data-driven decision support for Gators Athletics. This project examines three seasons of Florida football through five analytical lenses — team profile, situational tendencies, drive efficiency, win/loss discriminators, and SEC conference context — using the same framework a sports analytics staff would apply to inform in-season and off-season decisions.

The emphasis throughout is on **interpretable metrics** that connect directly to coaching decisions, not just predictive accuracy. Every figure answers a specific operational question.

---

## Research Questions

| Module | Question |
|--------|----------|
| **1. Team Profile** | How has UF's scoring output, yardage profile, and turnover rate changed across seasons? |
| **2. Situational Football** | Does performance differ meaningfully at home vs. away? How aggressive is UF on 4th down? |
| **3. Drive Performance** | What percentage of UF drives end in scores vs. empty possessions? |
| **4. Win vs. Loss Scripts** | Which metrics most strongly discriminate wins from losses? |
| **5. SEC Context** | How does UF rank among SEC peers on key efficiency metrics? |

---

## Key Findings (2022–2024)

| Finding | Detail |
|---------|--------|
| Scoring margin trend | See Figure 1 — improvement trajectory |
| Biggest win/loss gap | Drive scoring % and turnover rate (Figure 4) |
| 4th-down aggressiveness | Go-for-it rate vs. national avg (Figure 2) |
| SEC standing | UF vs. conference median on yards per play (Figure 5) |

> Figures are generated programmatically. See `figures/` for full output.

---

## Figures

### Figure 1 — Season Profile
![fig1](figures/fig1_team_profile.png)

### Figure 2 — Situational Football
![fig2](figures/fig2_situational.png)

### Figure 3 — Drive Performance
![fig3](figures/fig3_drive_performance.png)

### Figure 4 — Win vs. Loss Scripts
![fig4](figures/fig4_win_loss.png)

### Figure 5 — SEC Context (2024)
![fig5](figures/fig5_sec_context.png)

---

## Methodology

### Data
All data is pulled programmatically from the [College Football Data API](https://collegefootballdata.com):
- `GET /games` — game results and scores
- `GET /games/teams` — per-game team statistics
- `GET /drives` — drive-level outcomes
- `GET /plays?down=4` — 4th-down play-by-play
- `GET /stats/season?conference=SEC` — season-level conference stats
- `GET /ratings/sp` — SP+ efficiency ratings

### Metrics
- **Drive scoring %**: proportion of offensive drives ending in points
- **Empty drive %**: proportion ending in punt, turnover, or turnover on downs
- **Quick-strike drive**: scoring drive completed in ≤ 3 plays
- **3rd-down conversion %**: parsed from `n-of-m` format in CFBD response
- **Win/loss splits**: all stats conditioned on game outcome

---

## Reproducibility

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set your free CFBD API key
export CFBD_API_KEY="your_key_here"   # register at collegefootballdata.com/key

# 3. Download data
python src/data_prep.py

# 4. Run full analysis and generate figures
python src/analysis.py

# 5. Or explore interactively
jupyter notebook notebooks/uf_football_analysis.ipynb
```

---

## Project Structure

```
uf-football-analytics/
├── data/                          # downloaded via data_prep.py
│   ├── games.csv
│   ├── team_game_stats.csv
│   ├── drives.csv
│   ├── fourth_downs.csv
│   └── sec_season_stats.csv
├── figures/                       # all output figures (5 PNG files)
├── notebooks/
│   └── uf_football_analysis.ipynb
├── src/
│   ├── data_prep.py               # CFBD API download pipeline
│   └── analysis.py                # five analytical modules + figures
├── requirements.txt
└── README.md
```

---

## Limitations & Next Steps

- **Coverage**: CFBD data does not include proprietary tracking data (PFF grades, Next Gen Stats)
- **Sample size**: 3 seasons × ~13 games = ~39 game observations; interpret with appropriate caution
- **Next steps**:
  - Expand to opponent-adjusted metrics (SP+ context)
  - Add opponent quality filter (P4 conference opponents only)
  - Interactive Streamlit dashboard for live-season tracking

---

## References

- Baldwin, B., et al. (2020). nflfastR: Functions to Efficiently Access NFL Play-by-Play Data. *Journal of Quantitative Analysis in Sports*, 17(3).
- Connelly, B. (2018). *Study Hall: College Football, Its Stats, and Its Stories*. CreateSpace.
- Nestler, S. (2023). Decision Science in Football. INFORMS Annual Meeting, Phoenix, AZ.
- Winston, W., Nestler, S., & Pelechrinos, K. (2022). *Mathletics* (2nd ed.). Princeton University Press.
- College Football Data API. https://collegefootballdata.com

---

## Author

**Haeyong Chun**  
Ph.D. Candidate, Kinesiology — Michigan State University  
Sports Analytics Graduate Certificate, MSU (2025–present)  
[github.com/haeyong520](https://github.com/haeyong520)
